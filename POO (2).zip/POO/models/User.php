<?php

abstract class User{
    protected int $id;
    protected string $nomComplet;
    protected string $login;
    protected string $password;
    protected string $role;


    public function __construct()
    {
        
    }

    //Getters

    public function getNomComplet():string{
        return $this->nomComplet;
    }
    public function getLogin():string{
        return $this->login;
    }
    public function getPassword():string{
        return $this->password;
    }

    //Setters

    public function setNomComplet(string $nomComplet):void{
        $this->nomComplet=$nomComplet;
    }
    public function setLogin(string $login):void{
        $this->login=$login;
    }
    public function setPassword(string $password):void{
        $this->password=$password;
    }

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of role
     */ 
    public function getRole()
    {
        return $this->role;
    }

    /**
     * Set the value of role
     *
     * @return  self
     */ 
    public function setRole($role)
    {
        $this->role = $role;

        return $this;
    }
}