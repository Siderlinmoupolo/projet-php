<?php


class  Professeur extends User{
    //Attributs
        private string $nci;
        private string $email;
    //Méthodes
        
        


        /**
         * Get the value of nci
         */ 
        public function getNci()
        {
                return $this->nci;
        }

        /**
         * Set the value of nci
         *
         * @return  self
         */ 
        public function setNci($nci)
        {
                $this->nci = $nci;

                return $this;
        }

        /**
         * Get the value of email
         */ 
        public function getEmail()
        {
                return $this->email;
        }

        /**
         * Set the value of email
         *
         * @return  self
         */ 
        public function setEmail($email)
        {
                $this->email = $email;

                return $this;
        }

}