<?php

class Classe{
    //Attributs Instances
        private int $id;
        private string $libelle;
        public function inscriptions():array{
            return [];
        }
        public function reinscriptions():array{
            return [];
        }

    //Methoses D'instances
        //Constructeurs
        public function __construct()
        {
            
        }
        //Getters permet d'obtenir la valeur d'un attribut private ou protected
        public function getLibelle():string{
            return $this->libelle;
        }
        //Setters
        public function setLibelle($libelle):void{
            $this->libelle=$libelle;
        }
        //Metiers

        /**
         * Get the value of inscription
         */ 
        public function getInscription()
        {
                return $this->inscription;
        }

        /**
         * Set the value of inscription
         *
         * @return  self
         */ 
        public function setInscription($inscription)
        {
                $this->inscription = $inscription;

                return $this;
        }

        /**
         * Get the value of inscription
         */ 
        public function getReinscription()
        {
                return $this->inscription;
        }

        /**
         * Set the value of reinscription
         *
         * @return  self
         */ 
        public function setRinscription($inscription)
        {
                $this->inscription = $inscription;

                return $this;
        }

        /**
         * Get the value of id
         */ 
        public function getId()
        {
                return $this->id;
        }

        /**
         * Set the value of id
         *
         * @return  self
         */ 
        public function setId($id)
        {
                $this->id = $id;

                return $this;
        }
}