<?php
class AC extends User{
    public function affiche(){
        echo $this->id;
    }

    public function liste():array{
        return [];
    }
}