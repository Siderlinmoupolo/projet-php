<?php
//importer un fichier(require ou include)
require_once("./models/Classe.php");
require_once("./models/Module.php");
require_once("./models/DossierEtudiant.php");
require_once("./models/Etudiant.php");
require_once("../vendor/autoload.php");
require_once("./models/Reinscription.php");
require_once("./models/Professeur.php");
require_once("./models/Cours.php");
require_once("./models/User.php");
require_once("./models/AC.php");




//Creation des objets
$classe1=new Classe();
//donner un état à l'objet
$classe1->setLibelle("GLRS A");

$user=new User();
$user->setId(1);
$user->setLogin("Koumba");
$user->setPassword("ldd");
$user->setRole("role");


$dossierEtudiant=new DossierEtudiant();
$dossierEtudiant->setDateOuverture(new DateTime("2015-02-01"));
//echo($dossierEtudiant->getDateOuverture()->format('d/m/Y'));

$etudiant1=new Etudiant();
$etudiant1->setNomComplet("Médine Ndinga");
$etudiant1->setLogin("meme@gmail.com");
$etudiant1->setPassword("ism123");
$etudiant1->setMatricule("00001ISM");

echo("Nom : ".$etudiant1->getNomComplet()."\n");
echo("Login : ".$etudiant1->getLogin()."\n");
echo("Password : ".$etudiant1->getPassword()."\n");
echo("Matricule : ".$etudiant1->getMatricule()."\n");
echo("Role : ".$etudiant1->getRole()."\n");



