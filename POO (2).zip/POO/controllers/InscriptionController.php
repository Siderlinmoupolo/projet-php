<?php
class InscriptionController{
    
}